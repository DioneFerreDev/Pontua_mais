# Roleta (sorteio)

[![MIT License](https://img.shields.io/apm/l/atomic-design-ui.svg?)](https://github.com/tterb/atomic-design-ui/blob/master/LICENSEs)

Roleta para sortear itens com animação, sorteio configurado para 24 items.

![](header.png)

## Imagem
[![Sem-t-tulo.png](https://i.postimg.cc/Y2fxJ3Zm/Sem-t-tulo.png)](https://postimg.cc/BtbDFxqq)

## Requerimentos
- Nenhum

## Instalação e uso

Clone o projeto:
git clone https://github.com/PauloFelipeM/sorteio-valores-formato-rollete.git

Abra no navegador o arquivo index.html
Clique no centro da roleta ou aperte a tecla espaço.
